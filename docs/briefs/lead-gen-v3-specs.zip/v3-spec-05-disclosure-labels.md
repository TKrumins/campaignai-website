# V3 SPEC 05 — The Disclosure Label Generator

**Route:** `/disclosure-labels` · **Ends on:** two honest email offers (pack + tracker notify) · **Amendment A1 applies: THE GATE IS REMOVED.**

## North star
"They just gave me something useful, for free, with no fine print — and
they clearly take this seriously." The page IS the honest-broker argument;
its behavior must never contradict its thesis.

## Success metrics
Label composed in under 45 seconds; the meaningful/generic toggle used;
warm email opt-ins (fewer than the gate captured, worth more); bookmark/
return behavior via the labels list.

## Core experience

### Preview-first inversion (the punch-up)
The **mock ad player is the persistent centerpiece** from first paint — a
party-neutral fictional spot rendered large, with the label ON it. The four
questions (AI narration · AI visuals · AI b-roll mix · AI script assist;
"Check nothing if the piece is entirely real.") sit beside it, and **every
answer edits the label on the ad in real time**. The questionnaire stops
being a form; it becomes watching your label get built. Compose logic
remains the established Demo C logic, verbatim, unforked.

### The result — open, immediate, welded (amendment A1)
The composed plain-language label renders fully, instantly, un-gated, with
a one-click "Copy label" button. **Welded to it in the same card, every
time:** the state-wording reminder ◆ "Your state may require specific
wording. Check before you publish." + the standing not-legal-advice line.
The guardrails ship inside anything copied or emailed, not beneath it.

### The contrast, felt (upgrade of v2's static comparison)
On the visitor's OWN preview: a Generic ↔ Meaningful toggle. Flipping to
Generic wipes their specific label to "AI-GENERATED CONTENT" and a small
line names the loss: "A voter just lost the one thing they could act on:
knowing which parts are real." Flip back, the specifics return. Keep v2's
best caption ("Notice it never changes, no matter what you check.") on the
generic side. The v2 argument, now something that happens to them.

### "Your labels" (return value)
Each composed label can be saved to a client-side list (localStorage):
name-the-asset field + the label + date. "Label another asset" resets the
questions. This is the bookmark mechanic; no account, no server.

## The two email offers (replacing the gate — both genuine)
1. **The copy-ready pack:** "Want this label formatted three ways —
   caption text, spoken-disclosure wording for your script, and on-screen
   overlay text? We'll email you the pack." (EmailCapture, purpose
   `labelgen`; the pack content is generated from their label client-side
   and included in the capture payload.)
2. **The tracker notify** (see next section).
Privacy microcopy on both: ◆ "We'll never share your information or use it
to train major models."

## Regulatory tracker framing (per Tom: build the hooks now)
A new section beneath the result, `RegulatoryTrackerTeaser`:
- Heading: "Rules change by state — and by platform."
- Body: "Every state sets its own wording. Every platform (the social and
  ad networks your video runs on) sets its own AI rules. They keep
  changing. We track them so campaigns don't have to guess."
- UI hooks built NOW, honest holding state: a **state selector** and
  **platform chips** that currently resolve to: "Requirements vary and
  change often. Our live tracker is coming. Until then: check before you
  publish." Zero statute citations, zero named platform policies, platform
  names as chips only.
- **EmailCapture:** "Be first to know when the tracker goes live →"
  (purpose `tracker` — NEW MailerLite group; flag to Tom, must exist before
  ship).
- **Engineering hook:** the teaser consumes a stubbed data adapter
  (`getTrackerStatus(state, platform) → HoldingState`) so Tom's future
  dynamic state-by-state + platform tracker drops in behind the same
  interface with no layout change. Document the interface in the component.

## No badge (confirmed)
No "we disclose" credential is minted, ever. Visitors share the tool and
their label; CampaignAI never issues a trust mark it cannot police. Do not
add one in any future pass without explicit direction.

## Guided tour (then free play)
"Check one box — watch the ad →" (label updates live) → "Now flip it to
generic →" (the loss line) → "Flip it back. That difference is the whole
point →" → "Copy your label. It's yours →" (result + welded guardrails) →
"One more thing: rules move. We watch them →" (tracker teaser). Free play:
all questions, the toggle, the labels list.

## Content inventory (locked ◆)
◆ H1 · ◆ subtitle · ◆ state-wording reminder · not-legal-advice line ·
privacy microcopy · compose-logic output strings (verbatim from the
established logic). New strings (loss line, tracker section, pack offer,
tour prompts) in one sign-off block. Grep: zero statutes; "FEC" only inside
the badge; platform names only as chips.

## Motion & reduced-motion (paired)
Label live-edit on the preview ↔ instant text swap + aria-live ("Label
updated: …") · generic wipe ↔ instant swap with the loss line rendered ·
preview ambient motion (existing) ↔ still frame. The page is fully usable
with zero animation.

## Share payload
Text: "Free tool: answer four questions, get a plain-language AI disclosure
label for your campaign content. No email required." + URL. (Sharing the
stance and the tool; the no-email fact IS the differentiator.) Image card:
their label on the mock ad. OG: regenerate to the label-on-ad frame.

## Build spec
`DisclosureLabels.tsx` refactor: `AdPreview` (centerpiece, label slot),
`QuestionPanel`, `LabelResult` (label + welded guardrail card + copy
button), `ContrastToggle`, `LabelsList` (localStorage),
`RegulatoryTrackerTeaser` (+ stub adapter), two `EmailCapture` instances
(`labelgen`, `tracker`), `ShareKit`, `GuidedTour`, `LiveAnnouncer`.

## QA additions
The label is NEVER blurred, delayed, or conditioned on any input · welded
guardrails present in the DOM inside the result card and inside the pack
payload · both EmailCapture purposes hit distinct groups · tracker teaser
renders its holding state for every state × platform combination · labels
list survives reload · grep gates per 0.7.

## Open questions for Tom (PR, non-blocking)
1. Confirm the two MailerLite groups (`labelgen`, `tracker`) get created
   before deploy.
2. Platform chip set to ship with (proposal: Meta · Google/YouTube ·
   TikTok · X · Connected TV) — confirm or edit; chips are names only.
