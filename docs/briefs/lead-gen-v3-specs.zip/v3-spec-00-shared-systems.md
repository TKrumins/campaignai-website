# V3 SPEC 00 — Shared Systems (read before any of the five)

**For:** Claude Code, CampaignAI lead-gen experiences v3.
**Rule zero:** where this packet conflicts with the v2 briefs, THIS PACKET WINS.
The deltas below were explicitly authorized by Tom in the July 5 planning
session; do not "fix" them back to the old briefs.

---

## 0.1 Authorized amendments to the locked briefs

| # | Page | Old locked behavior | New behavior (authorized) |
|---|---|---|---|
| A1 | Disclosure Labels | Result email-gated (blurred until email) | **No gate.** Label renders fully, immediately. Email becomes two honest offers: the copy-ready pack + tracker-launch notify (see spec 05). |
| A2 | Story Arc Builder | Pricing as opportunity math in the widget | **All pricing strings removed from the widget.** Focus is the storytelling flywheel + content ecosystem. The purchase endcap (CTA + microcopy + waitlist + DELIVERY_LINE once) stays exactly as built. |
| A3 | Day on the Trail | Scroll-driven story | **Replaced by an interactive day-runner** (step + choice engine). Subtitle needs a one-word amendment; see spec 02 open questions. |
| A4 | Day on the Trail | Optional race-scale toggle | **Cut.** Beats stay level-ambiguous. |
| A5 | Voter's Eyes | Feed-only experience | **Full-page ghost reveal added as the finale** (see spec 01). |
| A6 | Campaign Machine | Dark-navy machine, 4 flat toggles | **Rebuilt as a 4-act light→dark→light experience** opening on the 8 automation stations (see spec 03). |

Everything else in the v2 briefs and README remains locked: H1s/subtitles/closing
lines verbatim (except A3's flagged word), conversion architecture, palette,
persona gauntlet, zero em dashes, "Starting at $___" wherever prices appear,
no statutes, "FEC" only inside the badge, party-neutral everything, no real
people, no competitor names (the "boutique agency" in spec 04 is a category,
never a name).

## 0.2 The realist rule (Tom's unease ceiling, now a written requirement)

Lean into discomfort, then soothe with the brand. Every dark or unsettling
beat in any experience MUST land on a warm, plain-language resolution within
one beat. We are realists showing a better path, never alarmists. Pattern:
name the uncomfortable truth → immediately name what stays human / what the
brakes are / why it's fixable. If a state can be screenshotted mid-dark with
no visible path back (except the Machine's deliberately staged Act 4 pre-
resolution frame), add the path back.

## 0.3 GuidedTour (shared component)

Every experience opens in a short guided preset, then unlocks free play.

- API: `<GuidedTour steps={[{target, prompt, advanceOn}]} onComplete>`.
- Renders: a floating prompt chip (Freedom Blue, Manrope 700, arrow) anchored
  to the current target + progress dots + an always-visible "Skip the tour"
  text button. No modal, no overlay that blocks the page.
- Steps advance on the named interaction (`advanceOn: 'click' | 'toggle' |
  'timer' | 'custom'`), never on scroll position alone.
- Completion (or skip) sets `localStorage['tour-{route}']`; returning visitors
  land in free play with a small "Replay the tour" affordance near the hero.
- Keyboard: prompt chip is announced via the LiveAnnouncer; targets stay in
  natural tab order; the tour never traps focus.
- Reduced motion: chip appears/disappears with no animation.

## 0.4 ShareKit (shared component) — "post to social," 1-2 clicks

One button per experience, placed at the payoff moment AND in the endcap.

- **Mobile (navigator.share available):** one tap opens the native share
  sheet, pre-filled with the payload text + page URL. Done in two taps total.
- **Desktop:** one click opens a compact popover: [Copy text + link] ·
  [Download image card] · X · LinkedIn · Facebook · Bluesky (intent URLs,
  new tab). Two clicks total.
- **Image card:** a branded PNG rendered client-side to a `<canvas>` from the
  visitor's actual result (their counter, their tally, their arc, their
  label). 1200×630, Regal Navy ground, Manrope headline, wordmark, page URL.
  One canvas renderer, five templates.
- **Honest constraint (tell Tom once, in code comments too):** link previews
  on social show the page's static OG image (`public/assets/og/{route}.png`),
  not the visitor's custom card. The custom card travels only when the
  visitor attaches the downloaded image. Both paths are first-class.
- Payload strings live in each page's spec (Section "Share payload"). All
  payloads pass the persona gauntlet; none contain numbers we can't derive
  from the visitor's own on-page data.
- OG images: regenerate each route's static OG to match its new signature
  frame (listed per spec).

## 0.5 LiveAnnouncer + accessibility floor (all five)

- One visually-hidden `aria-live="polite"` region per page; every state
  change that alters visible content announces a one-line summary.
- Every control: tap + click + keyboard operable, visible focus ring
  (2px Freedom Blue offset). Real `<button>`/`<input type=range>`/
  `role="switch"` with `aria-pressed`/`aria-checked`.
- Flips and reveals are semantically disclosures: `aria-expanded` on the
  trigger, content in DOM order after it.
- Decorative animation layers (ghost drifts, gears, palette washes) are
  `aria-hidden` and never receive focus.
- Contrast: check Beacon White on Critical Scarlet surfaces in the Machine's
  Act 4; darken the scarlet surface, never lighten the text.

## 0.6 Motion rules (all five)

- CSS transforms/opacity only for continuous motion; no layout-property
  animation; no scroll-linked animation APIs; IntersectionObserver drives
  entrance states. JS islands dynamic-imported; PDF lib (spec 04) loads only
  on click.
- Every animation in every spec is listed WITH its reduced-motion twin.
  Global pattern: `prefers-reduced-motion: reduce` converts each experience
  to stepped states with complete copy. The Trail's new step engine and the
  Machine's act structure make this nearly free; keep it that way.
- Lighthouse mobile stays green on every route; if a flourish costs the
  budget, the flourish loses.

## 0.7 Grep gates (run on all five before commit)

Zero `—` · zero "self-serve platform" · zero "20-minute" · "FEC" only inside
the compliance badge string · zero statute or platform-policy citations ·
Arc Builder page: zero "save", "savings", "only $", "instead of paying"
(now trivially true, keep the gate) · zero flag/heart emoji · prices, where
they appear anywhere, read "Starting at $___".
