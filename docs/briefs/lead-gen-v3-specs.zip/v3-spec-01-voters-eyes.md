# V3 SPEC 01 — Through the Voter's Eyes

**Route:** `/voters-eyes` · **Ends on:** NewsletterEndcap + "See how we make video →" · **Amendment A5 applies (ghost reveal finale).**

## North star
"I had no idea this much was aimed at me, and I couldn't see any of it
happening." Curiosity → mild vertigo → the green reassurance that a person
still decides. The reveal is the page.

## Success metrics
Reach the ghost reveal in under 60 seconds on the guided path; the reveal
counter is the screenshot; persona switch attempted by most free-players.

## Core experience

### Arrival: the week plays itself (owned decision)
~1s after load, the week begins auto-advancing (~50s Mon→Sun, eased pacing so
contacts arrive in a felt rhythm, denser late-week). Big visible Pause; the
scrubber (existing range input) is live at all times and pausing hands over
control. Reduced motion: no autoplay — a "Play the week" button steps
day-by-day with a visible day counter.

### The feed (keep, tighten)
Existing card system stays (text, sponsored ad + disclosure chip, email,
mailer, door knock, fundraising ask; persona-composed). Below 480px the
phone bezel is removed — the visitor's phone IS the phone; the feed goes
full-bleed with the status strip kept as a slim header.

### The flip, now two layers deep
Layer 1 (existing): the 3-step chain → ◆ green "what stayed human" line →
Socratic question. NEW Layer 2, "What the campaign now knows": one more tap
reveals 2-3 lines of CATEGORIES ONLY — "That you opened it. When. Whether
you tapped." Never specifics, never data-broker detail, always industry-
generic, and every Layer 2 closes with its own Verdant line ("A person
decided what to do with that."). Semantics: each layer is a disclosure
(`aria-expanded`), reading order front → chain → human line → question →
learned → human line.

### The persona diff (make the swap felt)
Switching persona (existing three) keeps the current week on screen and
animates the DELTA: departing cards slide out, arriving cards slide in, and
the touchpoint counter visibly re-counts to the new total. One qualitative
line summarizes the change from data, e.g. "As a donor, the asks come more
often." (Derived from the dataset's actual counts; no invented multipliers.)
Reduced motion: instant recompose + the summary line + aria-live announce.

## THE GHOST REVEAL (the finale — full page, per Tom: "make this splash")
The guided tour's last beat, and free play's centerpiece button ("Show me
everything →").

Choreography:
1. The phone frame dissolves outward and the FULL VIEWPORT becomes the
   stage: the page chrome dims, the visitor's seen-cards remain solid at
   center.
2. Ghost cards flood the entire viewport — faint, outlined, low-opacity
   drifting cards representing everything aimed at this persona that week
   that never registered: the ads that ran while she scrolled past, the
   message variants tested on neighbors but not her, the sends timed and
   re-timed around her habits. (All industry-generic; each ghost carries a
   one-line label; ghosts are `aria-hidden`, non-focusable.)
3. The counter lands huge, center, Manrope 800:
   **"This week: {seen} you saw · {unseen} you didn't."**
   Both numbers COMPUTED from the persona's dataset (never hardcoded).
4. The realist landing (one beat later, Verdant accent):
   "None of this is secret, or sinister on its own. It's just invisible.
   We think it shouldn't be."
5. ShareKit button rides the counter. "Back to the week ←" restores the feed.

Reduced motion: no drift, no dissolve — a full-screen stepped panel: seen
cards listed, then unseen listed as a static grid, then counter + landing
line. Full copy intact.

OG image: regenerate `public/assets/og/voters-eyes.png` as the counter frame.

## Guided tour (then free play)
"Watch her week arrive →" (timer: first 3 days play) → "Flip this one →"
(the sponsored ad; walks both layers) → "Now be someone else →" (persona
switch; the diff plays) → "One more thing. Show everything →" (the reveal).
Free play unlocks after: scrubber, all flips, personas, reveal button.

## Data/content model
`touchpoints.json`: per persona → per week → contacts[] {channel, front copy,
seen: boolean, chain[3], humanLine, socraticQ, learned[], learnedHumanLine,
ghostLabel?}. Seen/unseen counts derive from this file; copy lives here, not
in components. Ratio guidance: unseen ≈ 3-5× seen, varying by persona, every
ghost individually justifiable as ordinary industry practice.

## Content inventory (locked ◆)
◆ H1, ◆ subtitle, ◆ closing line, ◆ every "what stayed human" line pattern in
Verdant. New strings (reveal landing line, Layer 2 copy, ghost labels,
persona summaries) submitted as one copy block for sign-off; all must pass
the persona gauntlet, especially strategist neutrality and novice clarity.

## Motion & reduced-motion (paired)
Autoplay week ↔ stepped play button · card arrival slide ↔ instant append ·
flip rotation ↔ instant swap (existing) · persona diff animation ↔ instant
recompose + announce · ghost drift + dissolve ↔ stepped full-copy panel.

## Share payload
Text: "This week a campaign reached me {seen} times that I saw. And {unseen}
times I didn't. See your week:" + URL. Image card: the counter frame with
the persona name generic ("one voter's week").

## Build spec
`VotersEyes.tsx` refactor: `WeekEngine` (play/pause/scrub state),
`FeedCard` (3-state disclosure), `PersonaDiff`, `GhostReveal` (portal to a
full-viewport layer), `GuidedTour`, `ShareKit`, `LiveAnnouncer`. Autoplay
respects `document.visibilityState` (pause when tab hidden).

## QA additions
Counter math equals dataset counts on every persona · ghosts unreachable by
keyboard · reveal exits restore scroll position and focus · autoplay never
resumes after user pause · bezel removal at <480px · grep gates per 0.7.

## Open questions for Tom (PR, non-blocking)
1. Reveal landing line: sign off the exact soothe wording above.
2. Ghost density on low-power phones is capped (~20 rendered, counter can
   exceed rendered count honestly via "…and more"). Confirm the cap approach.
