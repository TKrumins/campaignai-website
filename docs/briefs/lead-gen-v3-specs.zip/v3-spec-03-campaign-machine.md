# V3 SPEC 03 — The Campaign Machine (build this one first)

**Route:** `/campaign-machine` · **Ends on:** NewsletterEndcap + "See how we make video →" · **Authorized amendment A6 applies.**

## North star
"Campaigns are already machines. The question is who can afford to run one —
and whether the one you run has brakes." Awe at the machinery, relief at the
staffing, trust at the refusals. The press piece.

## Success metrics
Complete the 4-act tour in under 90 seconds; the Act 4 resolution frame is
the designed screenshot; share rate highest of the five.

## The rebuild: four acts, light → dark → light

### Act 1 — The machinery you already run (Dawn Frost, warm daylight)
The page opens LIGHT: Dawn Frost ground, daytime warmth, the machine drawn
as a connected assembly of **eight stations, verbatim:** Emails · Social
posts · Volunteer intake · Donor intake · Media scheduling · Press releases ·
Data analytics · Issue analysis. At the center: the candidate and her people,
the hub every station connects to. Framing copy (new, locked on approval):

> "Every modern campaign runs this machine. Big campaigns run it with forty
> staffers. Yours runs it with five people and a group chat."

Each station, tapped or focused, shows its human-speed reality in one line
(the volunteer spreadsheet at midnight, the press release that went out a day
late, the donor thank-yous nobody had time to send). Perspective throughout:
the local, underfunded campaign. This act is the paywall thesis drawn as a
diagram.

### Act 2 — Flip the switch (the machine gets staffed)
The AI switch (locked H1 is its caption: "Flip the switch. Watch what speeds
up. Notice what doesn't."). On flip: stations spin up in a stagger, each
receiving a speed badge (×2, ×3, ×4 — vary honestly by station), belts run,
and the time-saved counter rolls — BUT the counter is a **receipt**: it
expands into an itemized per-station ledger, each line tagged
"illustrative." The candidate hub gets the badge **"×1. Always."** in
Verdant, held prominently. New meaning, per Tom: the switch doesn't just
accelerate the machine, it *staffs* it — a five-person campaign suddenly
operating like it has a back office. Line: "The switch doesn't replace your
people. It gives your five the reach of forty."

### Act 3 — Remove the humans
Keep v2's best material: inspector stations dim, output ships flagged, and
the three "What the human stations catch" cards (Tone that is off · Claims
that overreach · A frame that misrepresents) render with their existing
copy. Closing line of the act stays: "AI provides the speed. Humans provide
the judgment. Every output passes a person before it leaves."

### Act 4 — The dark turn (the only Critical Scarlet in the product)
Because Acts 1-3 are daylight, this act can finally land. Choreography:
1. The question renders as a real switch: "What happens without guardrails?"
2. On activate: daylight visibly DRAINS — a wash from the switch outward,
   Dawn Frost → near-black, machine silhouettes rimmed Critical Scarlet.
   (Reduced motion: instant state change.)
3. The four pattern→outcome cards (keep v2 copy: impersonation, fabricated
   video, deception at scale, misleading about voting) present ONE AT A
   TIME, each sliding toward the output bin — outcomes only, never methods.
4. "Restore the guardrails →" (Verdant, the only button on screen).
5. On restore: daylight floods back from the center, and the three refusals
   STAMP in sequence, one beat apart, Verdant on the returning light:
   "We will never impersonate a real person." · "We will never help deceive
   voters about how, when, or where to vote." · "We will never train major
   AI models on your campaign's data."
6. Soothe line (realist rule): "The dark timeline exists. Here is the
   company that built the brakes." (keep from v2).

**The press/OG frame is step 5:** three stamped refusals over the machine at
the moment light returns. Compose the layout so a mid-restore screenshot is
gorgeous; regenerate `public/assets/og/campaign-machine.png` to match.

## Guided tour (then free play)
"Meet the machine you already run →" (tap any station) → "Now flip the
switch →" → "Notice the one thing that didn't speed up →" (spotlight pulses
the ×1 badge) → "Now remove the humans →" → "One more. Ask what happens
without guardrails →" → tour completes on Restore. Free play: all toggles
live, plus auto-recovery — any destructive state left idle 20s surfaces a
gentle "Restore →" affordance; a persistent small Reset returns to Act 1.

## Mobile: vertical assembly line (real rebuild, authorized)
Below 768px the machine reflows top-to-bottom: hopper up top, stations
stacked as a production line, conveyor running vertically, candidate hub
visually central in the column, output bin at the base. Same acts, same
copy. Do not shrink the horizontal machine.

## Data/content model
`machine.json`: stations[8] {id, name, humanSpeedLine, aiSpeedBadge,
ledgerLine}; darkCards[4] {pattern, outcome}; refusals[3] (verbatim);
tourSteps. All display strings from data, no strings in components.

## Content inventory (locked marked ◆)
◆ H1, ◆ subtitle, ◆ closing line ("Every campaign now works this way…"),
◆ three refusals, ◆ "No candidate, no campaign. AI never changes that."
(remove-the-candidate stays available in free play), v2 catch-cards copy,
new Act 1 framing lines above (submit to Tom in the build PR as a copy
block for one-pass sign-off).

## Motion & reduced-motion (paired)
Stagger spin-up ↔ stations gain badges instantly, stepped · daylight drain
↔ instant dark state · card slide ↔ cards listed · refusal stamps ↔ all
three rendered with full copy · gear rotation (existing keyframes, keep the
`--gear-dur` same-element rule) ↔ static gears. Every act reachable and
fully readable with animation off.

## Share payload
Text: "Flip the switch. Watch what speeds up. Notice what doesn't. ×1.
Always." + URL. Image card: the ×1 badge over the daylight machine OR the
three refusals frame (visitor gets whichever state they shared from).

## Build spec
`CampaignMachine.tsx` refactor into `MachineStage` (SVG, acts as CSS state
classes on one root), `StationCard`, `LedgerCounter`, `DarkTurn`,
`GuidedTour` + `ShareKit` from spec 00. State machine: `act1 | act2 | act3 |
act4-dark | act4-restored | free`. Keyframes stay in globals.css.

## QA additions
Beacon-on-scarlet contrast per 0.5 · no destructive dead-ends (auto-recovery
verified) · aria-live announces each act · vertical mobile line legible at
360px · grep gates per 0.7.

## Open questions for Tom (in the PR, not blockers)
1. Act 1 framing lines and station one-liners: one-pass copy sign-off.
2. The remove-the-candidate toggle now lives in free play rather than the
   tour (four tour beats is the ceiling before it drags). Confirm.
