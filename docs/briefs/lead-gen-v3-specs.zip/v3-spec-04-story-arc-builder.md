# V3 SPEC 04 — The Story Arc Builder

**Route:** `/story-arc-builder` · **Ends on:** the ONE purchase endcap (unchanged: "Start with chapter one." + CTA_PRIMARY + CTA_MICROCOPY + waitlist secondary + DELIVERY_LINE once) · **Amendment A2 applies: zero pricing strings inside the widget.**

## North star
"I don't need *a* video. I need a story — and I can see the whole engine of
it, with these people as the spine." Abundance and authorship. The visitor
leaves holding a plan they built.

## Success metrics
Most visitors edit the dealt arc (authorship achieved); share-link and PDF
usage; the endcap converts because chapter one reads as the plan's obvious
first step.

## Core experience (three connected views, one state)

### View 1 — Build the arc (evolves the current builder)
- Inputs stay (race + goals chips, client-side privacy line ◆ "Nothing you
  enter here leaves your browser.").
- **Presets ("common experiences," per Tom):** five one-tap starting
  scenarios that pre-build an arc AND serve as the guided entry: First-time
  local candidate · Statewide challenger · Ballot initiative · Advocacy or
  nonprofit push · Incumbent re-elect. Picking one deals the arc; the tour
  then walks one edit, the flywheel, and the ecosystem.
- **Authorship:** the dealt arc is editable — add (rapid response, closing
  argument, second explainer), remove, reorder. Keyboard: per-chapter
  up/down buttons are the baseline; drag is an enhancement. Chapter 1 wears
  a "Start here" badge.
- **The voter journey line:** beneath the chapters, a rising line from
  "has never heard of you" → "votes for you," waypoints (meets you → trusts
  you → agrees with you → shows up). Chapters lift it; removals make it
  visibly sag or gap with a tooltip naming what breaks ("voters meet you,
  but never hear why"). Every edit redraws it live. Reduced motion: the
  line re-renders instantly; the tooltip copy carries the meaning.
- A **mapping matrix** drives real cause-and-effect: `arcs.json` enumerates
  race × goals → recommended sequence + emphasis + a one-line "why this
  arc" rationale (local leans testimonial/trust; statewide leans multiple
  explainers + rapid-response add-on; ballot initiative leads with the
  explainer; advocacy swaps GOTV for a take-action chapter). Different
  inputs must produce visibly different arcs.

### View 2 — The storytelling flywheel (new, per Tom)
A branded circular graphic: **Story → Content → Attention → Trust →
Turnout → People (volunteers, supporters, UGC) → back to Story.** As the
visitor's arc gains chapters and (View 3) content types, the flywheel
visibly gains segments and spins faster — the compounding-narrative
argument as motion. Caption: "Every piece feeds the next. One video is a
moment. An arc is momentum." Reduced motion: static flywheel with numbered
flow arrows, full copy.

### View 3 — The content ecosystem (new, per Tom; the honest-broker made visual)
An orbit map with **the campaign's story as the center** and four content
rings around it:
1. **The marquee spot** — "For the biggest moment, a boutique agency can be
   the right call. We'll tell you when it is." (category, never a name;
   this is the honest-broker line doing real work)
2. **The journey chapters** — the CampaignAI arc, the narrative spine
   (announcement → explainers → testimonial → GOTV)
3. **Candid, on-the-fly social video** — shot on a phone, authentic,
   fast
4. **Volunteer + supporter UGC** — the community telling the story with you
Connecting all four: **the consistent throughline** — one story, one voice,
one plan — rendered as threads from every ring back to the center. Line:
"Different makers, one story. The throughline is the plan you just built."
Toggling rings on adds their segments to the flywheel (Views 2 and 3 share
state). This view is where "we build their collective narrative" lives.

## Pricing (amendment A2)
No prices, no totals, no opportunity math anywhere in the widget. The grep
gate (0.7) stays enforced. The endcap is untouched and remains the page's
only commercial beat.

## Share link + PDF (both in, per Tom)

### "Send this plan" (URL-encoded, client-side)
One button copies a link; the arc state (preset, chapters, order, ecosystem
rings) is serialized into the URL fragment (`#a=…`), so the plan IS the
link — nothing stored, nothing sent, consistent with the privacy line.
Opening the link redraws the exact arc. Use case named in the UI: "Build it
at midnight. Text it to your candidate."

### "Download your content plan (PDF)" (CampaignAI-branded)
One click generates a branded one-to-two-page PDF client-side:
- Header: wordmark + "Your story arc" + date.
- The arc: chapters in order with each "sets up" interlock line.
- The journey line as a static snapshot.
- The ecosystem map with the throughline caption.
- **"Foundations vs. room to run"** section (per Tom's foundations/wiggle-
  room ask): Foundations = the four chapter types and why the order works;
  Room to run = add-on chapters, candid-video cadence, UGC prompts, rapid
  response — "the plan holds the story steady so the team can improvise
  everything else."
- Footer: info@campaignai.us + the page URL + "Nothing you entered left
  your browser; this PDF was made on your device."
Implementation: client-side PDF generation via a small utility lib (jsPDF-
class), **dynamic-imported on first click only** (zero page-load cost; this
is a utility, not an animation lib, and is within the platform rules).
Fallback if the lib is cut for budget: a print-stylesheet plan view +
"Save as PDF." Prefer the one-click lib.

## Guided tour (then free play)
Preset pick → "This is your arc. Try removing the testimonial →" (journey
line sags; tooltip explains; visitor restores it) → "Now see what the story
feeds →" (flywheel) → "And who else helps tell it →" (ecosystem) → "Send it
or save it →" (share link + PDF) → endcap. Free play unlocks everything.

## Content inventory (locked ◆)
◆ H1 "One video introduces you. A story arc elects you." · ◆ subtitle ·
◆ privacy line · endcap strings from constants (◆ CTA_PRIMARY,
◆ CTA_MICROCOPY, ◆ DELIVERY_LINE once, ◆ waitlist). New strings (rationales,
flywheel caption, ecosystem lines, sag tooltips, PDF copy) in one sign-off
block. Ecosystem ring 1 must never name an agency.

## Motion & reduced-motion (paired)
Journey line draw ↔ instant re-render + tooltip copy · flywheel spin-up ↔
static numbered flow · ring threads ↔ static lines · chapter reorder
animation ↔ instant with aria-live announce ("Testimonial moved to
position 3").

## Share payload
Text: "I just mapped my campaign's whole story: {n} chapters, one
throughline. Build yours:" + URL (their fragment link, so the arc travels).
Image card: their arc over the journey line. OG: regenerate to a journey-
line frame.

## Build spec
`StoryArcBuilder.tsx` refactor: `ArcState` (single source: preset, chapters,
order, rings; serializes to/from fragment), `ChapterList` (reorderable),
`JourneyLine` (SVG, data-driven), `Flywheel`, `EcosystemMap`, `PlanPDF`
(dynamic import), `ShareKit`, `GuidedTour`. `arcs.json` mapping matrix as
the content brain.

## QA additions
Every race × goals combination yields a distinct, rationale-bearing arc ·
fragment links round-trip losslessly · PDF renders on iOS Safari and
Android Chrome · keyboard-only build of a full custom arc verified · grep
gate: pricing terms absent from the widget DOM · endcap untouched.

## Open questions for Tom (PR, non-blocking)
1. PDF visual pass: approve the one-pager layout from a generated sample.
2. The five preset names above: confirm or rename.
