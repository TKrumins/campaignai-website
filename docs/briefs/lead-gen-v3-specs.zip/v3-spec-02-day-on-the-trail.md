# V3 SPEC 02 — A Day on the Trail

**Route:** `/day-on-the-trail` · **Ends on:** NewsletterEndcap + "See how we make video →" · **Amendments A3 (model replaced) and A4 (race toggle cut) apply.**

## North star
Rueful recognition: "this is insane, and it's true." The visitor doesn't
watch her day — they RUN it, and discover the workload is structural no
matter what they choose. The 3 hours back land as oxygen.

## The model change (authorized): from scroll story to day-runner
Tom rejected watch-and-scroll unless radically more interactive; choices are
always preferred. So the scroll is gone. The v3 is a **step-and-choice
engine on a fixed stage**:

- One SCENE at a time on a persistent stage (no long page). The time-of-day
  palette washes across the stage as the day advances (dawn golds → work
  whites → dusk violet → night navy) — the v2's best visual, now on one
  canvas instead of spread down a page.
- Persistent HUD: the clock (advances per stop), the **screen-vs-people
  meter** (now the co-star: a day-bar that visibly fills with "screen"
  color and crowds the sliver of "people" time), and the **carry tray** —
  completed screen-tasks stack as small icons she drags through the day, so
  the load is cumulative and visible.
- Each stop: a short animated scene beat (2-4s: the retake counter climbs,
  the caption re-types, the notification stack buzzes), then either
  auto-advance ("Next →") or a **CHOICE**.

### The choices (5 across 9 stops; every one teaches the trap)
Choices change flavor and order, never the ending — and that convergence IS
the argument, stated at the finale: "You made different choices than the
last visitor. The math came out the same. The workload is structural."

1. **6:10a The day job (anchor, no choice).** "Before she is a candidate,
   she is at work." (existing copy, keep)
2. **8:05a Parked-car filming.** Choice: "Use the take with the truck noise"
   vs "Re-film." → Use it: "Next to her opponent's polished spot, it reads
   as unpolished. She re-films." Either way, retakes tick the meter.
3. **12:20p Lunch-break screen triage.** Choice: reply to comments now vs
   at midnight. Now: lunch disappears into the screen bar. Later: the
   midnight stop visibly grows.
4. **3:40p The export stop (the locked fork).** "Skip the third
   aspect-ratio export?" → Skip: "Then it won't run on the platform where
   most of her voters actually scroll. She does it." The re-export runs;
   the tray gains its icon.
5. **6:15p Doors (anchor).** Choice: "Skip doors to finish the captions?"
   → Skip: "The doors are the campaign. She goes. The captions wait for
   midnight." (Doors are never actually skippable — choosing skip is
   answered and overridden by her; that's the character note.)
6. **9:30p–12:00a Night screen stack.** Grows or shrinks based on choices
   3/5; the meter hits its most lopsided frame here (the share/OG frame).
7. **The turn.** The screen shards that have been accumulating at the
   stage's edges (each screen-task adds a faint glowing rectangle crowding
   the scene) SHATTER; palette lifts to daylight; the 3 hours return,
   spent visibly at doors and in community. Tray icons for the absorbed
   tasks visibly lift out of her tray.
8. ◆ Closing line: "Her day had 17 hours in it. AI gave her 3 back."
   Realist landing beneath it: soft-sell "More doors, fewer screens." theme
   line + quiet `/how-it-works` link.

Anchors preserved per the locked spec: the day job and the doors are
unremovable beats.

## Guided vs free
The first run IS the guided experience (the engine is inherently guided).
Free play = "Run her day again" with choice memory cleared and a "make the
opposite calls" nudge; the convergence line only strengthens on a second run.

## Honesty framing (required)
Near the meter, small persistent caption: "One composite day, drawn from how
modern campaigns actually run." The 17/3 math is narrative and owned as
such; no measurement is implied.

## Data/content model
`stops.json`: stops[] {time, tag, headline, body, scene: sceneKey,
microInteraction, choice?: {prompt, options[2], responses[2],
meterDeltas, trayIcon?, affects?: stopId}}. Scene SVGs keyed, drawn in brand
tokens, 2-3 animated elements each.

## Content inventory (locked ◆)
◆ H1 "A day on the trail with a candidate." · ◆ closing line · day-job and
doors copy carried from v2 where it survives the new engine. **Subtitle
amendment required (A3):** the locked subtitle begins "Scroll through…" and
the page no longer scrolls. Proposed one-word amendment for Tom's sign-off:
"**Step through** one candidate's actual day and count the hours modern
digital campaigning demands she spend on a screen instead of with voters."
All new choice/response strings submitted as one copy block; sheriff-race
and Senate-race managers must both see their day (persona gauntlet #2).

## Motion & reduced-motion (paired)
Palette wash ↔ per-stop palette block, instant · scene micro-animations ↔
end-state stills · meter fill ↔ stepped fill with announced totals · shard
accumulation/shatter ↔ shard count as a static badge, turn as an instant
light state · stage transitions ↔ instant swaps. The step engine is natively
reduced-motion-friendly; the entire day is playable and readable with zero
animation. Keyboard: every choice is two real buttons; "Next" is a button;
nothing advances on scroll.

## Share payload
Text: "I just ran a candidate's day. {screen}h on a screen, {people}h with
voters. Then 3 hours came back." + URL. Image card: the lopsided meter
frame with the clock. OG: regenerate to the meter-at-worst frame.

## Build spec
`DayOnTheTrail.tsx` rebuild: `DayEngine` (stop index, choices, meter, tray
state), `Stage` (scene renderer + palette classes), `MeterHUD`, `CarryTray`,
`ChoiceBlock`, `ShareKit`, `LiveAnnouncer`. Scenes as an SVG sprite module.
Mobile-first: the fixed stage solves v2's mobile drag; verify at 360px.

## QA additions
Both branches of every choice reachable and copy-complete · convergence:
final meter identical across all choice paths · doors/day-job beats cannot
be skipped · no scroll hijacking anywhere · grep gates per 0.7.

## Open questions for Tom (PR, non-blocking)
1. ◆ Subtitle one-word amendment ("Scroll"→"Step") — sign-off required
   since the string is verbatim-locked.
2. Choice copy block sign-off (the five prompts + responses above).
